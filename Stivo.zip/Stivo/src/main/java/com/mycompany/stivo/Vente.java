/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.stivo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author patrick
 */
public class Vente {
    
    
    
    public void Ajouter(String nom, int prix_achat_u,int quantite,int prix_achat_t, int prix_vente_u, int prix_vente_total,int benefice){
    
        PreparedStatement pst;
        
        String sql = "INSERT INTO vente(nom,p_a_u,quantite,prix_achat_p,p_v_u,prix_vente_p,benefice) VALUES(?,?,?,?,?,?,?,now())";
    
        try{
            Connection con = new ConnectionDB().connect();
             pst = con.prepareStatement(sql);
             
             pst.setString(1, nom);
             pst.setInt(2,prix_achat_u);
             pst.setInt(3, quantite);
             pst.setInt(4, prix_achat_t);
             pst.setInt(5, prix_vente_u);
             pst.setInt(6,prix_vente_total);
             pst.setInt(7, benefice);
             
             
                    pst.execute();
                    con.close();
         
        }
        catch(Exception e)
            {
                JOptionPane.showMessageDialog(null,"erreureeeee :" + e);
            }
        
       
    }
    
    public void modifier(int quantite ,int pa, int pv,int benef,String nom){
    
    
        PreparedStatement pst;
    //int num = this.getId(nom);
    
    //"UPDATE stock SET quantiteseuil = ? WHERE nom = ? ";
    String sql = "UPDATE vente SET quantite = quantite +? ,prix_achat_p = prix_achat_p + ?,prix_vente_p = prix_vente_p + ?, benefice = benefice + ? WHERE nom = ?";

    try{
        Connection con = new ConnectionDB().connect();
        pst = con.prepareStatement(sql);
        
        //pst.setString(1, nom);
        pst.setInt(1, quantite);
        pst.setInt(2, pa);
        pst.setInt(3,pv );
        pst.setInt(4, benef);
        pst.setString(5, nom);
 
            pst.execute();
            con.close();
        
    }

    catch(Exception e)
            {
                JOptionPane.showMessageDialog(null,"erreurrrrrr:" + e);
            }
    }
    
    
    
    
    public boolean getNom(String nom,Date date){
        boolean exist = false;
    
        try{
        Connection con = new ConnectionDB().connect();
        PreparedStatement pst;
        ResultSet rst;
        
        String sql = "SELECT id_v FROM vente WHERE nom = ? AND date = ?";
        pst = con.prepareStatement(sql);
        pst.setString(1, nom);
        pst.setDate(2, (java.sql.Date) date);
        
        
       
        rst = pst.executeQuery();
        
        if(rst.next()){
  
     exist =true;
     
     return exist;
}

else{
  
    exist = false;
}
        
        }
        
        catch(Exception e)
            {
                JOptionPane.showMessageDialog(null,"erreuraaaaaa ici:" + e);
            }
        return exist;
    
    }
    
    
    public void supprimer(String nom){
    
    
        PreparedStatement pst;
        String sql = "DELETE FROM vente WHERE nom = ?";
        Admin a = new Admin();

            try{

                Connection con = new ConnectionDB().connect();
                
                pst = con.prepareStatement(sql);
                pst.setString(1, nom);
                
                    pst.execute();
                    con.close();
                   
            }
            catch(Exception e)
            {
                JOptionPane.showMessageDialog(null,"erreur ici:" + e);
            }
    
    }
    
    
    
    
    
    
    public List<Object[]> getVenteDate(String date){

List<Object[]> liste = new ArrayList<Object[]>();
        
    PreparedStatement pst;
    ResultSet rst;
    
    String sql = "SELECT nom,p_a_u,quantite,prix_achat_p,p_v_u,prix_vente_p,benefice FROM vente WHERE date = ?";
        
        try{
                Connection con = new ConnectionDB().connect();
        pst = con.prepareStatement(sql);
        pst.setString(1, date);
        rst = pst.executeQuery();
        int som = 0;
        while(rst.next()){
        
                        
                       String nom = rst.getString("nom");
                       int p_a_u = rst.getInt("p_a_u");
                       int quantite = rst.getInt("quantite");
                       int pat = rst.getInt("prix_achat_p");
                       int p_v_u = rst.getInt("p_v_u");
                       int pvt = rst.getInt("prix_vente_p");
                        int benef = rst.getInt("benefice");
                        som+=benef;
                        
                        
                        Object[] ligne = {nom,p_a_u,quantite,pat,p_v_u,pvt,benef};
           liste.add( ligne);
                   
        }
    
       
        
        }

            catch(Exception e)
            {
                JOptionPane.showMessageDialog(null,"erreur ici:" + e);
            }

    return liste;
}
    
}
