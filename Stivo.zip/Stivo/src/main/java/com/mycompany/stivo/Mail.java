/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.stivo;

import java.util.List;
import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

/**
 *
 * @author patrick
 */






public class Mail {
    
    
    
    private String username = "medicationalpha@gmail.com";
    private String password = "tuhcgvbyyxfxlxgh";
    int code = 0;

public int envoyer(String mail){

    
    //etape1: création d'une session
    Properties props = new Properties();
    props.put("mail.smtp.auth", "true");
    props.put("mail.smtp.starttls.enable", "true");
    props.put("mail.smtp.host", "smtp.gmail.com");
    props.put("mail.smtp.port", "587");
    
    Session session = Session.getInstance(props,
            new javax.mail.Authenticator() {
                
                protected PasswordAuthentication getPasswordAuthentication(){
                
                    return new PasswordAuthentication(username,password);
                }
            });
    
    try{
    
        //etape 2:cr&qtion du message
        int nombreAleatoire = 100000 + (int)(Math.random() * ((999999 - 100000) + 1));
        Message message = new MimeMessage(session);
        message.setFrom(new InternetAddress("medicationalpha@gmail.com"));
        message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(mail));
        message.setSubject("Code de confirmation");
        message.setText("Le code de récupération est :"+nombreAleatoire);
        
        //etape3:envoi du message
        Transport.send(message);
        this.code = nombreAleatoire;
        return this.code;
        
        
    }
    catch(MessagingException e){
        
        throw new RuntimeException(e ) ;
    }

}


//fonction pour récupérer les identifiants de connexion si on mes a oubliés
//elle prend en parametre l'email et une liste qui contient les identifiants
public void send(String mail,List<String> l){

    
    //etape1: création d'une session
    Properties props = new Properties();
    props.put("mail.smtp.auth", "true");
    props.put("mail.smtp.starttls.enable", "true");
    props.put("mail.smtp.host", "smtp.gmail.com");
    props.put("mail.smtp.port", "587");
    
    Session session = Session.getInstance(props,
            new javax.mail.Authenticator() {
                
                protected PasswordAuthentication getPasswordAuthentication(){
                
                    return new PasswordAuthentication(username,password);
                }
            });
    
    try{
    
        //etape 2:cr&qtion du message
        //int nombreAleatoire = 100000 + (int)(Math.random() * ((999999 - 100000) + 1));
        Message message = new MimeMessage(session);
        message.setFrom(new InternetAddress("medicationalpha@gmail.com"));
        message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(mail));
        message.setSubject("Récupération des identifiants");
        String login = l.get(0);
        String password = l.get(1);
        message.setText("Votre login est :"+login +"\n Votre mot de passe est: " +password);
        
        //etape3:envoi du message
        Transport.send(message);
        
        
        
    }
    catch(MessagingException e){
        
        throw new RuntimeException(e ) ;
    }

}


//fonction qui envoiet pas mail les identifiants apres creation d'un nouveau compte
public void sendIdentifiants(String mail,List<String> l){

    
    //etape1: création d'une session
    Properties props = new Properties();
    props.put("mail.smtp.auth", "true");
    props.put("mail.smtp.starttls.enable", "true");
    props.put("mail.smtp.host", "smtp.gmail.com");
    props.put("mail.smtp.port", "587");
    
    Session session = Session.getInstance(props,
            new javax.mail.Authenticator() {
                
                protected PasswordAuthentication getPasswordAuthentication(){
                
                    return new PasswordAuthentication(username,password);
                }
            });
    
    try{
    
        //etape 2:cr&qtion du message
        //int nombreAleatoire = 100000 + (int)(Math.random() * ((999999 - 100000) + 1));
        Message message = new MimeMessage(session);
        message.setFrom(new InternetAddress("medicationalpha@gmail.com"));
        message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(mail));
        message.setSubject("Identifiants de connection chez Stivo FUELEC");
        
        String login = l.get(0);
        String password = l.get(1);
        
        message.setText("Votre login est :"+login +"\n Votre mot de passe est: " +password);
        
        //etape3:envoi du message
        Transport.send(message);
        
        
        
    }
    catch(MessagingException e){
        
        throw new RuntimeException(e ) ;
    }

}


}
