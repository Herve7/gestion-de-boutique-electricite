/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.stivo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author patrick
 */
public class ConnectionDB {
        
    private Connection connection;
    
    public Connection connect(){
    try{
        Class.forName("com.mysql.jdbc.Driver");
        //System.out.println("pilote chargés");
    }
      catch(ClassNotFoundException e){
      
          //System.out.println("pilote non chargé" + e);
      }
    String url = "jdbc:mysql://localhost:3306/stivo";
    
   
    
    try{
        connection = (Connection) DriverManager.getConnection(url,"root","jesusmonroi");
      // System.out.println("connection réussie");
    }
    
    catch(SQLException e){
    
    //System.out.println("connection échouée" +e);
    }
       
    
     return connection; 
    }
}


