/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.stivo;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.Font;
import static com.itextpdf.text.Font.BOLD;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.draw.LineSeparator;
import java.awt.Desktop;



import java.io.File;
import java.io.FileOutputStream;
import java.sql.Array;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import static java.time.Instant.now;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import javax.mail.MessagingException;
import javax.swing.JOptionPane;
import javax.swing.text.Element;

/**
 *
 * @author patrick
 */
public class Produit {
    
    
    
    
    public boolean existNom(String nom){
        
         boolean exist = false;
    
try{
Connection con = new ConnectionDB().connect();
PreparedStatement pst;
ResultSet rst;

String sql = "SELECT id_p FROM produit WHERE nom = ?";
pst = con.prepareStatement(sql);
pst.setString(1, nom);
rst = pst.executeQuery();



if(rst.next()){
    //System.out.println("Il existe ");
     exist =true;
     
     return exist;
}

else{
   //System.out.println("Il n'existe pas");
    exist = false;
}
}
catch(Exception e)
            {
                JOptionPane.showMessageDialog(null,"erreur ici:" + e);
            }
        return exist;
    }
    
    
    public void Ajouter(String nom,int quantite,int prix_achat,int prix_vente){
    
        PreparedStatement pst;
        
        String sql = "INSERT INTO produit(nom,quantite,date,date_modif,prix_achat,prix_vente) VALUES(?,?,now(),null,?,?)";
    
        try{
            Connection con = new ConnectionDB().connect();
             pst = con.prepareStatement(sql);
             pst.setString(1, nom);
             pst.setInt(2, quantite);
             pst.setInt(3, prix_achat);
             pst.setInt(4, prix_vente);
             
             if(this.existNom(nom) == true){
                 JOptionPane.showMessageDialog(null,"Ce prodit existe déjà dans la base de données!!!\n Vérifiez l'ortographe et " +
                 "réessayez ou alors veuillez juste le modifeir");
                 
             }
             else{
             
                    pst.execute();
                    con.close();
                   
             }
            
        }
        catch(Exception e)
            {
                JOptionPane.showMessageDialog(null,"erreur :" + e);
            }
        
       
    }
    
    
    public boolean existProduit(String nom){
        
         boolean exist = false;
    
try{
Connection con = new ConnectionDB().connect();
PreparedStatement pst;
ResultSet rst;

String sql = "SELECT id_p FROM produit WHERE nom = ?";
pst = con.prepareStatement(sql);
pst.setString(1, nom);
rst = pst.executeQuery();



if(rst.next()){
    //System.out.println("Il existe ");
     exist =true;
     
     return exist;
}

else{
   //System.out.println("Il n'existe pas");
    exist = false;
}
}
catch(Exception e)
            {
                JOptionPane.showMessageDialog(null,"erreur ici:" + e);
            }
        return exist;
    }
    
    
    public List<String[]>retournerLigne(String nom){
    
        List<String[]> liste = new ArrayList<String[]>();
        
        try{
            Connection con = new ConnectionDB().connect();
            PreparedStatement pst;
            ResultSet rst;
            
            String sql = "SELECT nom,quantite,date,date_modif,prix_achat,prix_vente FROM produit WHERE nom =?";
            pst = con.prepareStatement(sql);
            pst.setString(1, nom);
            rst = pst.executeQuery();
            
            while(rst.next()){
       
           String bd_nom = rst.getString("nom");     
             
           String bd_qte = rst.getString("quantite");
           String bd_date = rst.getString("date");
           
           String bd_date_modif = rst.getString("date_modif");
           
           String bd_pa = rst.getString("prix_achat");
           
           String bd_pv = rst.getString("prix_vente");
           
           String[] ligne = {bd_nom,bd_qte,bd_pa,bd_pv,bd_date,bd_date_modif};
           liste.add( ligne);
          
       }
            
        }
        catch(Exception e)
            {
                JOptionPane.showMessageDialog(null,"erreur iciiiiiiiiiiii:" + e);
            }
        return liste;
    }
    
    
    public List<String[]> remplirTab(){
    
        List<String[]> liste = new ArrayList<String[]>();
        
        try{
        
            Connection con = new ConnectionDB().connect();
            PreparedStatement pst;
            ResultSet rst;
       
       String sql = "SELECT nom,quantite,date,date_modif,prix_achat,prix_vente FROM produit ORDER BY nom ASC";
       pst = con.prepareStatement(sql);
       
       rst = pst.executeQuery();
       while(rst.next()){
       
             String bd_nom = rst.getString("nom");
           //int bd_qte = rst.getInt("quantite");
           String bd_qte = rst.getString("quantite");
           //Date bd_date = rst.getDate("date");
           String bd_date = rst.getString("date");
           //Date bd_date_modif = rst.getDate("date_modif");
           String bd_date_modif = rst.getString("date_modif");
           //int bd_pa = rst.getInt("prix_achat");
           String bd_pa = rst.getString("prix_achat");
           //int bd_pv = rst.getInt("prix_vente");
           String bd_pv = rst.getString("prix_vente");
           
           String[] ligne = {bd_nom,bd_qte,bd_pa,bd_pv,bd_date,bd_date_modif};
           liste.add( ligne);
           
       }
        
        }
        catch(Exception e)
            {
                JOptionPane.showMessageDialog(null,"erreur iciiiiiiiiiiii:" + e);
            }
    
    return liste;
    }
    
    
    public void supprimer(String nom){
    
    
        PreparedStatement pst;
        String sql = "DELETE FROM produit WHERE nom = ?";
        Admin a = new Admin();

            try{

                Connection con = new ConnectionDB().connect();
                
                pst = con.prepareStatement(sql);
                pst.setString(1, nom);
                
                    pst.execute();
                    con.close();
                   
            }
            catch(Exception e)
            {
                JOptionPane.showMessageDialog(null,"erreur ici:" + e);
            }
    
    }
    
    public int getId(String nom){
    

int id = 0;
        String sql = "SELECT id_p FROM produit WHERE nom =? ";
        try{
            Connection con =  new ConnectionDB().connect();
            PreparedStatement pst;
            ResultSet rst;

            pst = con.prepareStatement(sql);
            pst.setString(1, nom);
            
            rst = pst.executeQuery();
           
            rst.next();
            id = rst.getInt(1);
            System.out.println(id);
            rst.close();
           pst.close();
}

        catch(Exception e)
            {
                JOptionPane.showMessageDialog(null,"erreur iciiiiii:" + e);
            }
        
        return id;
    
    }
    
    public void modifierCode(int quantite ,int pa,int pv,String nm){

    PreparedStatement pst;
    //int num = this.getId(nom);
    
    //"UPDATE stock SET quantiteseuil = ? WHERE nom = ? ";
    String sql = "UPDATE produit SET quantite = quantite +? ,prix_achat = ?,prix_vente = ? ,date_modif = now() WHERE nom = ?";

    try{
        Connection con = new ConnectionDB().connect();
        pst = con.prepareStatement(sql);
        
        //pst.setString(1, nom);
        pst.setInt(1, quantite);
        pst.setInt(2, pa);
        pst.setInt(3, pv);
        pst.setString(4, nm);
 
            pst.execute();
            con.close();
        
    }

    catch(Exception e)
            {
                JOptionPane.showMessageDialog(null,"erreurrrrrr:" + e);
            }
}
    
    
    
    
    
    
    
    
    
    public List<String> remplirCombo(){
    
        List<String> liste = new ArrayList<String>();
        
        try{
        
            Connection con = new ConnectionDB().connect();
            PreparedStatement pst;
            ResultSet rst;
       
       String sql = "SELECT nom FROM produit ORDER BY nom ASC";
       pst = con.prepareStatement(sql);
       
       rst = pst.executeQuery();
       while(rst.next()){
       
             String nom = rst.getString("nom");
           liste.add( nom);
           
       }
       
       
        
        }
        catch(Exception e)
            {
                JOptionPane.showMessageDialog(null,"erreur iciiiiiiiiiiii:" + e);
            }
    
    return liste;
    }
    
    
    public int getQuantite(String nom){
    

int quantite = 0;
        String sql = "SELECT quantite FROM produit WHERE nom =? ";
        try{
            Connection con =  new ConnectionDB().connect();
            PreparedStatement pst;
            ResultSet rst;

            pst = con.prepareStatement(sql);
            pst.setString(1, nom);
            
            rst = pst.executeQuery();
           
            rst.next();
            quantite = rst.getInt(1);
            
            rst.close();
           pst.close();
}

        catch(Exception e)
            {
                JOptionPane.showMessageDialog(null,"erreur iciiiiii:" + e);
            }
        
        return quantite;
    
    }
    
    public void setQuantiteMoins(int quantite,String nom){


    try{
        
                    int m = this.getQuantite(nom);
                    
    
            PreparedStatement pst;
            ResultSet rs;
            Connection con = new ConnectionDB().connect();
            String sql = "UPDATE produit SET quantite = quantite-?  WHERE nom = ? ";
            pst = con.prepareStatement(sql);
            
            pst.setInt(1, quantite);
            pst.setString(2, nom);
 
                    
                    
                    
                     pst.execute();
                        
                     con.close();
                      //  JOptionPane.showMessageDialog(null,"Retrait effectuer avec succes");  
                        int p = this.getQuantite(nom);
                        if(p <= 5){
            
                JOptionPane.showMessageDialog(null, "ATTENTION LE IL NE RESTE PLUS QUE "+p+" "+ nom+"(s)"+" PENSEZ À RÉAPPROVISIONNER LE STOCK");
            }
                 
    }
    
    catch(Exception e)
            {
                JOptionPane.showMessageDialog(null,"erreur ici:" + e);
            }
}
    
    
    
    
    public void setQuantitePlus(int quantite,String nom){


    try{
        
                    int m = this.getQuantite(nom);
                    
    
            PreparedStatement pst;
            ResultSet rs;
            Connection con = new ConnectionDB().connect();
            String sql = "UPDATE produit SET quantite = quantite+?  WHERE nom = ? ";
            pst = con.prepareStatement(sql);
            
            pst.setInt(1, quantite);
            pst.setString(2, nom);

                     pst.execute();
                     con.close();
                      //  JOptionPane.showMessageDialog(null,"Retrait effectuer avec succes");  
    }
    
    catch(Exception e)
            {
                JOptionPane.showMessageDialog(null,"erreur ici:" + e);
            }
}
    
    
    
    public List<Object[]> remplirCritique(){
    
        List<Object[]> liste = new ArrayList<Object[]>();
        
        try{
        
            Connection con = new ConnectionDB().connect();
            PreparedStatement pst;
            ResultSet rst;
       
       String sql = "SELECT nom,quantite FROM produit WHERE quantite <=10";
       pst = con.prepareStatement(sql);
       
       rst = pst.executeQuery();
       while(rst.next()){
       
             String bd_nom = rst.getString("nom");
           int bd_qte = rst.getInt("quantite");
           //String bd_qte = rst.getString("quantite");
           
           
           Object[] ligne = {bd_nom,bd_qte};
           liste.add( ligne);
           
       }
        
        }
        catch(Exception e)
            {
                JOptionPane.showMessageDialog(null,"erreur iciiiiiiiiiiii:" + e);
            }
    
    return liste;
    }
    
    
    
    public void printProduit(String nom_client,String nom_vendeur,String ptt,List<Object[]> l1){
    
    
        File folder = new File("documents");
        if(!folder.exists()){
        
            folder.mkdir();
        }
        
        String nom_fichier = "documents/informations_du_produit.pdf";
        
        Font TitleFont = new Font(Font.FontFamily.TIMES_ROMAN,24,Font.BOLD);
        Font f = new Font(Font.FontFamily.TIMES_ROMAN,8,Font.BOLD);
        Font fi = new Font(Font.FontFamily.TIMES_ROMAN,14,Font.BOLD);
        Font fli = new Font(Font.FontFamily.TIMES_ROMAN,14);
        Font flip = new Font(Font.FontFamily.TIMES_ROMAN,14,Font.UNDERLINE);
        Font RedFont = new Font(Font.FontFamily.TIMES_ROMAN,16,Font.BOLD,BaseColor.RED);
        
        
        
        Document document = new Document();
        
        try{
            
       PdfWriter.getInstance(document, new FileOutputStream(nom_fichier));
       document.open();
       document.addTitle("FACTURE DE STIVO FUELEC");
       document.addAuthor("patrick");
       
       
       
       Paragraph preface = new Paragraph();
       Paragraph titre = new Paragraph("            ETS STIVO FUELEC\n",TitleFont);
       
       Paragraph t1 = new Paragraph("                               COMMERCE GENERAL\n");
       
       
       Paragraph t2 = new Paragraph("                SITUE À OBOBOGO À 100M APRES L'ENTRÉE PALOMA EN VENANT DE DAMAS\n",f);
       Paragraph t3 = new Paragraph("                                       Tél:655 104 826");
       
       //titre.setAlignment(Element.ALIGN_CENTER);
       preface.add(titre);
       preface.add(t1);
       preface.add(t2);
       preface.add(t3);
       
       
       
       
       
       Paragraph pref = new Paragraph();
       
       
       PdfPTable tableau = new PdfPTable(2);
       tableau.setSpacingBefore(50);
       tableau.setWidthPercentage((float) 100.0);
       float[] columnWidths = {70f,30f};
       tableau.setWidths(columnWidths);
       tableau.setSpacingBefore(25);
       
       //j'ajoute la premiere preface a la premiere cellule et j'efface ses bordures
       PdfPCell cellule1 = new PdfPCell(preface);
       cellule1.setBorder(PdfPCell.NO_BORDER);
       //cellule1.setHorizontalAlignment(10);
       tableau.addCell(cellule1);
       
       
       
       
       //récupération de la date et de l'heure de la machine
       LocalDate dete = java.time.LocalDate.now();
        LocalTime h = java.time.LocalTime.now();
        Calendar cal = Calendar.getInstance();
        int heur = cal.get(Calendar.HOUR_OF_DAY);
        int min = cal.get(Calendar.MINUTE);
        int sec = cal.get(Calendar.SECOND);
        
        
        
       Paragraph fact = new Paragraph("\n\n\nN° FACTURE:\n",fli);
       Paragraph dat = new Paragraph("DATE:" + dete + "\n",fli);
       Paragraph heure = new Paragraph("HEURE:" + heur + ":" + min +":" + sec,fli);
       //j'ajoute la deuxieme preface a la premiere cellule et j'efface ses bordures
       PdfPCell cellule2 = new PdfPCell(pref);
       pref.add(fact);
       pref.add(dat);
       pref.add(heure);
       cellule2.setBorder(PdfPCell.NO_BORDER);
       //cellule2.setHorizontalAlignment(10);
       tableau.addCell(cellule2);
       
       
       //creation du tableau
       PdfPTable tab = new PdfPTable(4);
       float[] colum = {55f,15f,15f,15f};
       tab.setWidths(colum);
       tab.setSpacingBefore(15);
       tab.setSpacingAfter(0);
       
       //je crée un nouveau tableau pour mettre le client et le vendeur
       PdfPTable tab1 = new PdfPTable(2);
       Phrase f1 = new Phrase("Nom du vendeur : " +nom_vendeur);
       Phrase f2 = new Phrase("         Nom du client : " +nom_client);
       
       PdfPCell cel1 = new PdfPCell(f1);
       PdfPCell cel2 = new PdfPCell(f2);
       
       cel1.setBorder(PdfPCell.NO_BORDER);
       cel2.setBorder(PdfPCell.NO_BORDER);
       
       tab1.addCell(cel1);
       tab1.addCell(cel2);
       
       tab1.setSpacingBefore(30);
       tab1.setWidthPercentage((float) 100.0);
       
       
       PdfPCell c1 = new PdfPCell(new Phrase("Désignation",fi));
       c1.setHorizontalAlignment(10);
       
       tab.addCell(c1);
       
        c1 = new PdfPCell(new Phrase("Quantité",fi));
       c1.setHorizontalAlignment(5);
       tab.addCell(c1);
       
        c1 = new PdfPCell(new Phrase("PU HT",fi));
       c1.setHorizontalAlignment(5);
       tab.addCell(c1);
       
        c1 = new PdfPCell(new Phrase("MT HT",fi));
       c1.setHorizontalAlignment(5);
       tab.addCell(c1);
       
       
       
       Connection con = new ConnectionDB().connect();
            PreparedStatement pst;
            ResultSet rst;
       
       String sql = "SELECT nom,quantite,date,date_modif FROM produit ORDER BY nom ASC";
       pst = con.prepareStatement(sql);
       
       rst = pst.executeQuery();
       
       //je parcours la liste d'objets que j'ai passé en parametre
       for(int i = 0; i<l1.size();i++){
       
           Object[] ob = l1.get(i);
           String des = (String) ob[0];
           int qte = (int) ob[1];
           String qtes = Integer.toString(qte);
           int pu = (int) ob[2];
           String pus = Integer.toString(pu);
           int pt = (int) ob[3];
           String pts = Integer.toString(pt);
           
           tab.addCell(des);
           tab.addCell(qtes);
           tab.addCell(pus);
           tab.addCell(pts);
           
       
       }
       
       
      
       //je crée le tableau qui va afficher le montant total
       float[] columnWidth = {55f,30f,15f};
       PdfPTable tab2 = new PdfPTable(3);
       
       Phrase m1 = new Phrase("");
       Phrase m2 = new Phrase("Montant total à payer");
       Phrase m3 = new Phrase(ptt);
       
       PdfPCell cell1 = new PdfPCell(m1);
       PdfPCell cell2 = new PdfPCell(m2);
       PdfPCell cell3 = new PdfPCell(m3);
       
       cell1.setBorder(PdfPCell.NO_BORDER);
       /*cell2.setBorder(PdfPCell.NO_BORDER);
       cell3.setBorder(PdfPCell.NO_BORDER);*/
       
       tab2.addCell(cell1);
       tab2.addCell(cell2);
       tab2.addCell(cell3);
       
       tab2.setWidths(columnWidth);
       tab2.setSpacingBefore(0);
       tab2.setWidthPercentage((float) 100.0);
       
       
       //sa c'est pour le premier tableau
       tab.setHeaderRows(1);
       tab.setWidthPercentage((float) 100.0);
       
       //je crée un nouveau tableau pour la signature du client et celle du caissier
       //float[] columnWidth = {55f,30f,15f};
       PdfPTable tab3 = new PdfPTable(2);
       
       Phrase w1 = new Phrase("Signature du caissier");
       Phrase w2 = new Phrase("                         Signature du client");
       
       
       PdfPCell cellw1 = new PdfPCell(w1);
       PdfPCell cellw2 = new PdfPCell(w2);
       
       
       cellw1.setBorder(PdfPCell.NO_BORDER);
       cellw2.setBorder(PdfPCell.NO_BORDER);
       
       
       tab3.addCell(cellw1);
       tab3.addCell(cellw2);
       
       tab3.setSpacingBefore(30);
       tab3.setWidthPercentage((float) 100.0);
       
       
       PdfPTable tab4 = new PdfPTable(2);
       tab4.setSpacingAfter(90);
      
       document.add(tableau);
       document.add(tab1);
       document.add(tab);
       document.add(tab2);
       document.add(tab3);
       document.add(tab4);
       
       
       //2 ieme partie de la facture
       document.add(tableau);
       document.add(tab1);
       document.add(tab);
       document.add(tab2);
       document.add(tab3);
       
       document.close();
       
       
       
       

       File open = new File(nom_fichier);
       Desktop desk = Desktop.getDesktop();
       desk.open(open);
       
       
       
        }
        catch(Exception e)
            {
                JOptionPane.showMessageDialog(null,"erreur icirrrrrrrrr:" + e);
            }
        
    }

    
    
    
    public int getPrixAchat(String nom){
    

int prix = 0;
        String sql = "SELECT prix_achat FROM produit WHERE nom =? ";
        try{
            Connection con =  new ConnectionDB().connect();
            PreparedStatement pst;
            ResultSet rst;

            pst = con.prepareStatement(sql);
            pst.setString(1, nom);
            
            rst = pst.executeQuery();
           
            rst.next();
            prix = rst.getInt(1);
            
            rst.close();
           pst.close();
           return prix;
}

        catch(Exception e)
            {
                JOptionPane.showMessageDialog(null,"erreur iciiiiii:" + e);
            }
        
        return prix;
    
    }
    
}
