/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.stivo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author patrick
 */
public class Admin {
    
    
    
    
    
    
        public boolean getLogin(String nom){
        boolean exist = false;
    
        try{
        Connection con = new ConnectionDB().connect();
        PreparedStatement pst;
        ResultSet rst;
        
        String sql = "SELECT id FROM admin WHERE login = ? ";
        pst = con.prepareStatement(sql);
        pst.setString(1, nom);
       
        rst = pst.executeQuery();
        
        if(rst.next()){
  // System.out.println("existe deja");
     exist =true;
     
     return exist;
}

else{
  //System.out.println("n'existe pas");
    exist = false;
}
        
        }
        
        catch(Exception e)
            {
                JOptionPane.showMessageDialog(null,"erreur ici:" + e);
            }
        return exist;
    
    }

    public String getPass(String nom){
    
        
        String code = "";
        PreparedStatement pst;
        ResultSet rst;
        String sql = "SELECT pass FROM admin WHERE login = ?";
        
        try{
            Connection con = new ConnectionDB().connect();

            if(this.getLogin(nom) == false){
            
                JOptionPane.showMessageDialog(null, "le nom est incorrect vérifiez le et reessayez");
            }
            else{
            pst = con.prepareStatement(sql);
            pst.setString(1, nom);
            
            rst = pst.executeQuery();
           
            rst.next();
            code = rst.getString(1);
            
            
            rst.close();
           pst.close();
           return code;
           
            }
        }
                catch(Exception e)
            {
                JOptionPane.showMessageDialog(null,"erreur ici:" + e);
            }
        return code;
        
    }
    
    
    
    
    public void ajouter(String login,String pass,String mail){
    
        PreparedStatement pst;
        String sql = "INSERT INTO admin(login,pass,mail) VALUES(?,?,?)";
        Admin a = new Admin();


        try{

            Connection con = new ConnectionDB().connect();
            pst = con.prepareStatement(sql);
            pst.setString(1, login);
            pst.setString(2, pass);
            pst.setString(3,mail);
            
                if(this.getLogin(login) == true){
                    JOptionPane.showMessageDialog(null,"Ce login a déja été utilisé pour un compte existant veuillez le changer");
                }
                else if(this.existCode(pass) == true){
                    JOptionPane.showMessageDialog(null,"Ce mot de passe a déja été utilisé pour un compte existant veuillez le changer");
                }
                else{
                    pst.execute();
                    con.close();
                    JOptionPane.showMessageDialog(null,"Création du nouveau compte réussie");
                }
        }
        
        catch(Exception e)
            {
                JOptionPane.showMessageDialog(null,"erreur ici:" + e);
            }

    }
    
    
    
    
    public boolean existCode(String code){
        
         boolean exist = false;
    
try{
Connection con = new ConnectionDB().connect();
PreparedStatement pst;
ResultSet rst;

String sql = "SELECT id FROM admin WHERE pass = ?";
pst = con.prepareStatement(sql);
pst.setString(1, code);
rst = pst.executeQuery();



if(rst.next()){
    System.out.println("Il existe ");
     exist =true;
     
     return exist;
}

else{
   System.out.println("Il n'existe pas");
    exist = false;
}
}
catch(Exception e)
            {
                JOptionPane.showMessageDialog(null,"erreur ici:" + e);
            }
        return exist;
    }
    
    
      public void supprimer(String nom){
    
        PreparedStatement pst;
        String sql = "DELETE FROM admin WHERE nom = ?";
        Admin a = new Admin();

            try{

                Connection con = new ConnectionDB().connect();
                
                pst = con.prepareStatement(sql);
                pst.setString(1, nom);
                if(this.getLogin(nom) == false){
                    JOptionPane.showMessageDialog(null,"Impossible de supprimer ce compte car il n'existe pas");
                }
                else{
                    //je récupère le mot de passe du login qui a été entré
                    String pass = getPass(nom);
                    
                    String [] ob = {nom,pass};
                    
                    int confirmation = JOptionPane.showConfirmDialog(null, Arrays.toString(ob), "Supprimer le compte?", JOptionPane.YES_NO_OPTION);
                    if(confirmation == JOptionPane.YES_OPTION){
                    pst.execute();
                    con.close();
                    JOptionPane.showMessageDialog(null,"Suppression réussie");
                    }
                    else{
                        JOptionPane.showMessageDialog(null,"Suppression Annulé");
                    }
                    
                    
                }
            }
            catch(Exception e)
            {
                JOptionPane.showMessageDialog(null,"erreur ici:" + e);
            }
    
    }
    
      
      public List<String> getIdentifiants(String mail){
    
        List<String> liste = new ArrayList<String>();
        
        try{
        
            Connection con = new ConnectionDB().connect();
            PreparedStatement pst;
            ResultSet rst;
       
       String sql = "SELECT login,pass FROM admin WHERE mail = ?";
       pst = con.prepareStatement(sql);
       
       pst.setString(1, mail);
       
       rst = pst.executeQuery();
       while(rst.next()){
       
             String login = rst.getString("login");
           String pass = rst.getString("pass");
           //String bd_qte = rst.getString("quantite");
           
           
           
           
           liste.add( login);
           liste.add(pass);
           
       }
        
        }
        catch(Exception e)
            {
                JOptionPane.showMessageDialog(null,"erreur iciiiiiiiiiiii:" + e);
            }
    
    return liste;
    }
      
      
      public boolean existMail(String mail){
        
         boolean exist = false;
    
try{
Connection con = new ConnectionDB().connect();
PreparedStatement pst;
ResultSet rst;

String sql = "SELECT id FROM admin WHERE mail = ?";
pst = con.prepareStatement(sql);
pst.setString(1, mail);
rst = pst.executeQuery();



if(rst.next()){
    //System.out.println("Il existe ");
     exist =true;
     
     return exist;
}

else{
   //System.out.println("Il n'existe pas");
    exist = false;
}
}
catch(Exception e)
            {
                JOptionPane.showMessageDialog(null,"erreur ici:" + e);
            }
        return exist;
    }
    
}
